package com.example.longbox2.Fragments;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.longbox2.Database.DBHandler;
import com.example.longbox2.Enums.PublicationFormat;
import com.example.longbox2.MainActivity;
import com.example.longbox2.Objects.Comic;
import com.example.longbox2.R;
import com.example.longbox2.Utils.EnumUtils;

import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link AddComicFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AddComicFragment extends Fragment implements View.OnClickListener {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private EditText editAddTitle;
    private EditText editAddVolume;
    private EditText editAddIssue;
    private Spinner spnAddPublisher;
    private EditText editAddCoverPrice;
    private Spinner spnAddCondition;
    private Spinner spnAddFormat;
    private EditText editAddNotes;

    private ImageView btnAddTakePicture;
    private ImageView btnAddFindImage;

    private ImageView btnAddSave;
    private ImageView btnAddMore;
    private ImageView btnAddCancel;

    private MainActivity mainActivity;
    private DBHandler dbHandler;

    private AddComicFragmentInteractionListener mListener;

    public AddComicFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment AddComicFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static AddComicFragment newInstance(String param1, String param2) {
        AddComicFragment fragment = new AddComicFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_add_comic, container, false);

        editAddTitle = view.findViewById(R.id.editAddTitle);
        editAddVolume = view.findViewById(R.id.editAddVolume);
        editAddIssue = view.findViewById(R.id.editAddIssue);
        spnAddPublisher = view.findViewById(R.id.spnAddPublisher);
        editAddCoverPrice = view.findViewById(R.id.editAddCoverPrice);
        spnAddCondition = view.findViewById(R.id.spnAddCondition);
        spnAddFormat = view.findViewById(R.id.spnAddFormat);
        editAddNotes = view.findViewById(R.id.editAddNotes);

        btnAddTakePicture = view.findViewById(R.id.btnAddTakePicture);
        btnAddFindImage = view.findViewById(R.id.btnAddFindImage);

        btnAddSave = view.findViewById(R.id.btnAddSave);
        btnAddMore = view.findViewById(R.id.btnAddMore);
        btnAddCancel = view.findViewById(R.id.btnAddCancel);

        mainActivity = (MainActivity)getActivity();
        dbHandler = new DBHandler(getContext());

        btnAddTakePicture.setOnClickListener(this);
        btnAddFindImage.setOnClickListener(this);
        btnAddSave.setOnClickListener(this);
        btnAddMore.setOnClickListener(this);
        btnAddCancel.setOnClickListener(this);

        loadPublisherSpinner();
        loadConditionSpinner();
        loadFormatSpinner();

        //ToDo: Creators block
        //ToDo: Ability to add a new publisher
        spnAddPublisher.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(spnAddPublisher.getSelectedItem().toString().equalsIgnoreCase(getResources().getString(R.string.add_publisher))) {
                    //Pop up to add a new publisher
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        return view;
    }

    @Override
    public void onClick(View v) {
        if(v.getId() == btnAddSave.getId()) {
            //Add comic logic
            if(minimumRequirementsCheck()) {
                Comic comic = createComicObject();
                if(dbHandler.addComic(comic)) {
                    //Success
                    showSuccessToast();
                    mainActivity.loadMainFragment();
                } else {
                    //Failure
                    showFailureToast();
                }
            } else {
                notEnoughInfoDialog();
            }

        } else if(v.getId() == btnAddCancel.getId()) {
            //Cancel logic
            if(checkIfEmpty()) {
                //Nothing inputted. Just load the main fragment
                mainActivity.loadMainFragment();
            } else {
                //Confirm cancel
                cancelDialog();
            }
        } else if(v.getId() == btnAddTakePicture.getId()) {
            //Use camera to take pic of cover
            //ToDO: Camera interaction
        } else if(v.getId() == btnAddFindImage.getId()) {
            //Find a picture stored on the phone
            //ToDO: File navigation
        } else if(v.getId() == btnAddMore.getId()) {
            //Add the comic and refresh the page
            if(minimumRequirementsCheck()) {
                Comic comic = createComicObject();
                if(dbHandler.addComic(comic)) {
                    //Success
                    showSuccessToast();
                    mainActivity.loadAddComicFragment();
                } else {
                    //Failure
                    showFailureToast();
                }
            } else {
                notEnoughInfoDialog();
            }
        }
    }

    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onAddComicFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof AddComicFragmentInteractionListener) {
            mListener = (AddComicFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface AddComicFragmentInteractionListener {
        // TODO: Update argument type and name
        void onAddComicFragmentInteraction(Uri uri);
    }

    private void loadPublisherSpinner() {
        List<String> publishers = dbHandler.getAllPublishers();
        publishers.add(getResources().getString(R.string.add_publisher));

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_item, publishers);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnAddPublisher.setAdapter(adapter);
    }

    private void loadConditionSpinner() {
        List<String> conditions = EnumUtils.getAllConditions();

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_item, conditions);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnAddCondition.setAdapter(adapter);
    }

    private void loadFormatSpinner() {
        List<String> formats = EnumUtils.getAllFormats();
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_item, formats);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnAddFormat.setAdapter(adapter);
    }

    private boolean minimumRequirementsCheck() {
        boolean reqsMet = false;

        if(!editAddTitle.getText().equals("")) {
            if(!editAddIssue.getText().equals("")) {
                reqsMet = true;
            }
        }
        return reqsMet;
    }

    private boolean checkIfEmpty() {
        boolean empty = false;

        if(editAddTitle.getText().equals("")) {
            if(editAddVolume.getText().equals("")) {
                if(editAddIssue.getText().equals("")) {
                    if(editAddCoverPrice.getText().equals("")) {
                        if(editAddNotes.getText().equals("")) {
                            empty = true;
                        }
                    }
                }
            }
        }
        return empty;
    }

    private void cancelDialog() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(getContext());
        alertDialog.setMessage("Are you sure you want to cancel?");
        alertDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                mainActivity.loadMainFragment();
            }
        });
        alertDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //Nothing needs to happen
            }
        });
        alertDialog.create();
        alertDialog.show();
    }

    private void notEnoughInfoDialog() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(getContext());
        alertDialog.setMessage("More information is needed before you can save");
        alertDialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
    }

    private Comic createComicObject() {
        Comic comic = new Comic();

        comic.setComicTitle(editAddTitle.getText().toString());
        comic.setComicVolume(editAddVolume.getText().toString());
        comic.setComicIssue(editAddIssue.getText().toString());
        comic.setComicPublisherName(spnAddPublisher.getSelectedItem().toString());
        comic.setComicCoverPrice(editAddCoverPrice.getText().toString());
        comic.setComicConditionText(spnAddCondition.getSelectedItem().toString());
        comic.setComicFormat(PublicationFormat.valueOf(spnAddFormat.getSelectedItem().toString()));
        //ToDo: Cover image
        //ToDo: Creators

        comic.setComicNotes(editAddNotes.getText().toString());

        return comic;
    }

    private void showSuccessToast() {
        Toast.makeText(getContext(), "Comic added successfully", Toast.LENGTH_SHORT).show();
    }

    private void showFailureToast() {
        Toast.makeText(getContext(), "Comic Not Added. Please Try Again", Toast.LENGTH_SHORT).show();
    }
}
