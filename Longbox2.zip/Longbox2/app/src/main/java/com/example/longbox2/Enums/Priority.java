package com.example.longbox2.Enums;

public enum Priority {
    HIGH,
    MEDIUM,
    LOW
}
